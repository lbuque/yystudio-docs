/*
 * SPDX-FileCopyrightText: lbuque <1102390310@qq.com>
 *
 * SPDX-License-Identifier: MIT
 */

#include <Arduino.h>


void setup()
{
    Serial.begin(115200);
    delay(100);

    Serial.println("Hello, SparkC3!");
}

void loop()
{

    delay(5);
}
