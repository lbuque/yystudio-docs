#pragma once

#include "MontserratBold16.h"
#include "MontserratBoldItalic32.h"
#include "MontserratMedium9.h"
#include "MontserratMedium14.h"
#include "MontserratRegular14.h"
#include "MontserratRegular32.h"
#include "MontserratSemiBold9.h"
#include "MontserratSemiBold14.h"

extern const unsigned char MontserratBold16[];
extern const unsigned char MontserratBoldItalic32[];
extern const unsigned char MontserratMedium9[];
extern const unsigned char MontserratMedium14[];
extern const unsigned char MontserratRegular14[];
extern const unsigned char MontserratRegular32[];
extern const unsigned char MontserratSemiBold9[];
extern const unsigned char MontserratSemiBold14[];
