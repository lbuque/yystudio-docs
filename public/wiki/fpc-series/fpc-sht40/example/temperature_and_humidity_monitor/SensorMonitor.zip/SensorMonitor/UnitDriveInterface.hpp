#pragma once

#include <Arduino.h>
#include <Wire.h>

typedef enum {
    UNIT_STATUS_UNKNOWN = 0,
    UNIT_STATUS_PROBED,
    UNIT_STATUS_INITIALIZED,
    UNIT_STATUS_DEINITING,
    UNIT_STATUS_DEINITIALIZED,
} UnitStatus;

class UnitDriveInterface
{
public:
    UnitDriveInterface() {}
    virtual ~UnitDriveInterface() {}

    virtual void probe();
    virtual void init();
    virtual void deinit();
    virtual void run();
};
